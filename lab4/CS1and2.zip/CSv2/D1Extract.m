t = D1.time;
u=D1.signals(1).values(:,1);
e=D1.signals(1).values(:,2);
i=D1.signals(2).values(:,1);
n=D1.signals(3).values(:,1);
Omega=pi*n/30;
