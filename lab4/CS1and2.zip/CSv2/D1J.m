plot(t(ind_s:ind_e), Omega(ind_s:ind_e));

xlabel('Time(s)')
ylabel('\omega (rad/s)')